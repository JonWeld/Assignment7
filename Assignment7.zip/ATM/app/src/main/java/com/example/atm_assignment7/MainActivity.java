package com.example.atm_assignment7;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.app.Activity;



public class MainActivity extends Activity {

    private EditText pinInput;
    private Button loginButton;
    private int pin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pinInput = findViewById(R.id.pin_input);
        loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPin();
            }
        });
    }

    private void checkPin() {
        String pinString = pinInput.getText().toString();
        if (pinString.length() == 4) {
            pin = Integer.parseInt(pinString);
            showMenu();
        } else {
            Toast.makeText(this, "Invalid PIN. Please enter a 4-digit number.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMenu() {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }

    public int getPin() {
        return pin;
    }

}





