package com.example.atm_assignment7;

import android.content.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.app.*;

import java.text.*;
import java.util.*;


public class MenuActivity extends Activity {

    private int currentBalance = 0;

    private TextView balanceTextView;
    private Button depositButton;
    private Button withdrawButton;
    private Button transferButton;

    private Button receiptButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        TextView menuText = findViewById(R.id.menu_text);
        depositButton = findViewById(R.id.deposit_button);
        withdrawButton = findViewById(R.id.withdraw_button);
        transferButton = findViewById(R.id.transfer_button);
        balanceTextView = findViewById(R.id.balance_text_view);
        receiptButton = findViewById(R.id.receipt_button);

        receiptButton.setOnClickListener(v -> printReceipt());

        updateBalanceText();
    }

    private void updateBalanceText() {
        balanceTextView.setText(getString(R.string.currentAccBalance, currentBalance));
    }

    public void onDepositButtonClicked(View view) {
        currentBalance += 20;
        updateBalanceText();

        Toast.makeText(this, "Deposit successful", Toast.LENGTH_SHORT).show();
    }

    public void onWithdrawButtonClicked(View view) {
        if (currentBalance >= 20) {
            currentBalance -= 20;
            updateBalanceText();

            Toast.makeText(this, "Withdrawal successful", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show();
        }
    }

    public void onTransferButtonClicked(View view) {
        if (currentBalance >= 20) {
            currentBalance -= 20;
            updateBalanceText();

            Toast.makeText(this, "Transfer successful", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, TransactionActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show();
        }
    }

    private void printReceipt() {
        int receiptNumber = new Random().nextInt(1000000);

        Date now = new Date();

        String dateTime = DateFormat.getDateTimeInstance().format(now);

        String transactionType = getIntent().getStringExtra("transaction_type");

        int amount = new Random().nextInt(5) * 20;

        String receiptText = "Receipt #" + receiptNumber + " Date/Time: " + dateTime + " Transaction Type: " + transactionType + "\n" + "Amount: $" + amount;

        Toast.makeText(getApplicationContext(), receiptText, Toast.LENGTH_LONG).show();
    }

    public void onBackButtonClicked(View view) {
        finish();
    }

}

