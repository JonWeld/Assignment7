package com.example.atm_assignment7;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import java.text.*;
import java.util.*;

public class TransactionActivity extends Activity {

    private TextView transactionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        Intent intent = getIntent();
        String type = intent.getStringExtra("type");

        transactionText = findViewById(R.id.transaction_text);
        transactionText.setText("Transaction type: " + type);

    }
}

